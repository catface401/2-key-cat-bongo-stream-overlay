﻿import asyncio
import websockets
from pynput import keyboard
import sounddevice as sd
import numpy as np

clients = set()
keys_down = set()
is_talking = False
last_state = None

def audio_callback(indata, frames, time, status):
    global is_talking
    volume = np.linalg.norm(indata)
    is_talking = volume > 2  # adjust if needed

async def send_state():
    global last_state
    while True:
        base_state = 'idle'
        if 's' in keys_down and 'd' in keys_down:
            base_state = 'sd'
        elif 's' in keys_down:
            base_state = 's'
        elif 'd' in keys_down:
            base_state = 'd'

        overlay = 'talking' if is_talking else 'none'

        state = f"{base_state}|{overlay}"

        if state != last_state:
            print(f"state = {state}, keys_down = {keys_down}, is_talking = {is_talking}")
            last_state = state

        for ws in clients.copy():
            try:
                await ws.send(state)
            except websockets.exceptions.ConnectionClosed:
                clients.discard(ws)

        await asyncio.sleep(0.01)

async def handler(websocket):
    clients.add(websocket)
    try:
        await websocket.wait_closed()
    finally:
        clients.discard(websocket)

def on_press(key):
    try:
        if key.char == 's':
            keys_down.add('s')
        elif key.char == 'd':
            keys_down.add('d')
    except AttributeError:
        pass

def on_release(key):
    try:
        if key.char == 's':
            keys_down.discard('s')
        elif key.char == 'd':
            keys_down.discard('d')
    except AttributeError:
        pass

def start_keyboard_listener():
    listener = keyboard.Listener(on_press=on_press, on_release=on_release)
    listener.start()

def start_mic_listener():
    return sd.InputStream(callback=audio_callback)

def main():
    start_keyboard_listener()
    mic_stream = start_mic_listener()
    mic_stream.start()

    async def runner():
        async with websockets.serve(handler, "localhost", 8765):
            await send_state()

    asyncio.run(runner())

if __name__ == "__main__":
    main()
